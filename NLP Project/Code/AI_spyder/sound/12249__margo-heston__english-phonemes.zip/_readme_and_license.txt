Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - margo_heston ( https://freesound.org/people/margo_heston/ )

You can find this pack online at: https://freesound.org/people/margo_heston/packs/12249/

License details
---------------

Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 193326__margo-heston__wuh.wav
    * url: https://freesound.org/s/193326/
    * license: Attribution Noncommercial
  * 193325__margo-heston__zh.wav
    * url: https://freesound.org/s/193325/
    * license: Attribution Noncommercial
  * 193324__margo-heston__yyuh.wav
    * url: https://freesound.org/s/193324/
    * license: Attribution Noncommercial
  * 193323__margo-heston__kss.wav
    * url: https://freesound.org/s/193323/
    * license: Attribution Noncommercial
  * 193322__margo-heston__vvv.wav
    * url: https://freesound.org/s/193322/
    * license: Attribution Noncommercial
  * 193321__margo-heston__zzz.wav
    * url: https://freesound.org/s/193321/
    * license: Attribution Noncommercial
  * 193320__margo-heston__th.wav
    * url: https://freesound.org/s/193320/
    * license: Attribution Noncommercial
  * 193319__margo-heston__oo.wav
    * url: https://freesound.org/s/193319/
    * license: Attribution Noncommercial
  * 193318__margo-heston__uh.wav
    * url: https://freesound.org/s/193318/
    * license: Attribution Noncommercial
  * 193313__margo-heston__oy.wav
    * url: https://freesound.org/s/193313/
    * license: Attribution Noncommercial
  * 193312__margo-heston__shh.wav
    * url: https://freesound.org/s/193312/
    * license: Attribution Noncommercial
  * 193311__margo-heston__hw.wav
    * url: https://freesound.org/s/193311/
    * license: Attribution Noncommercial
  * 193310__margo-heston__nng.wav
    * url: https://freesound.org/s/193310/
    * license: Attribution Noncommercial
  * 193309__margo-heston__ooo.wav
    * url: https://freesound.org/s/193309/
    * license: Attribution Noncommercial
  * 193308__margo-heston__oww.wav
    * url: https://freesound.org/s/193308/
    * license: Attribution Noncommercial
  * 193307__margo-heston__arr.wav
    * url: https://freesound.org/s/193307/
    * license: Attribution Noncommercial
  * 193306__margo-heston__au.wav
    * url: https://freesound.org/s/193306/
    * license: Attribution Noncommercial
  * 193305__margo-heston__ch.wav
    * url: https://freesound.org/s/193305/
    * license: Attribution Noncommercial
  * 193304__margo-heston__err.wav
    * url: https://freesound.org/s/193304/
    * license: Attribution Noncommercial
  * 193285__margo-heston__ohh.wav
    * url: https://freesound.org/s/193285/
    * license: Attribution Noncommercial
  * 193284__margo-heston__pp.wav
    * url: https://freesound.org/s/193284/
    * license: Attribution Noncommercial
  * 193283__margo-heston__k.wav
    * url: https://freesound.org/s/193283/
    * license: Attribution Noncommercial
  * 193282__margo-heston__ll.wav
    * url: https://freesound.org/s/193282/
    * license: Attribution Noncommercial
  * 193281__margo-heston__mm.wav
    * url: https://freesound.org/s/193281/
    * license: Attribution Noncommercial
  * 193280__margo-heston__nn.wav
    * url: https://freesound.org/s/193280/
    * license: Attribution Noncommercial
  * 193279__margo-heston__g.wav
    * url: https://freesound.org/s/193279/
    * license: Attribution Noncommercial
  * 193278__margo-heston__hh.wav
    * url: https://freesound.org/s/193278/
    * license: Attribution Noncommercial
  * 193277__margo-heston__ih.wav
    * url: https://freesound.org/s/193277/
    * license: Attribution Noncommercial
  * 193276__margo-heston__jj.wav
    * url: https://freesound.org/s/193276/
    * license: Attribution Noncommercial
  * 193275__margo-heston__rr.wav
    * url: https://freesound.org/s/193275/
    * license: Attribution Noncommercial
  * 193274__margo-heston__qu.wav
    * url: https://freesound.org/s/193274/
    * license: Attribution Noncommercial
  * 193273__margo-heston__tt.wav
    * url: https://freesound.org/s/193273/
    * license: Attribution Noncommercial
  * 193272__margo-heston__ss.wav
    * url: https://freesound.org/s/193272/
    * license: Attribution Noncommercial
  * 193271__margo-heston__ewe.wav
    * url: https://freesound.org/s/193271/
    * license: Attribution Noncommercial
  * 193270__margo-heston__ff.wav
    * url: https://freesound.org/s/193270/
    * license: Attribution Noncommercial
  * 193269__margo-heston__aye.wav
    * url: https://freesound.org/s/193269/
    * license: Attribution Noncommercial
  * 193268__margo-heston__d.wav
    * url: https://freesound.org/s/193268/
    * license: Attribution Noncommercial
  * 193267__margo-heston__ee.wav
    * url: https://freesound.org/s/193267/
    * license: Attribution Noncommercial
  * 193266__margo-heston__eh.wav
    * url: https://freesound.org/s/193266/
    * license: Attribution Noncommercial
  * 193265__margo-heston__aah.wav
    * url: https://freesound.org/s/193265/
    * license: Attribution Noncommercial
  * 193264__margo-heston__ahh.wav
    * url: https://freesound.org/s/193264/
    * license: Attribution Noncommercial
  * 193263__margo-heston__aww.wav
    * url: https://freesound.org/s/193263/
    * license: Attribution Noncommercial
  * 193262__margo-heston__ay.wav
    * url: https://freesound.org/s/193262/
    * license: Attribution Noncommercial


